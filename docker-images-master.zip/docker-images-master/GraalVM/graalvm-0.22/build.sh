#!/bin/sh
docker build -t oracle/graalvm:0.22 .
