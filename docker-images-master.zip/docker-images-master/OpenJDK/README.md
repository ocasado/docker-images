OpenJDK Pre-built Packages on Oracle Linux
===============
Docker images based on Oracle Linux with OpenJDK (from OL repository) installed. Always containing latest major versions updates, and the 'latest' tag pointing at latest major version update.

# Copyright
Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
