#!/bin/sh
docker build -t 1221-webtier .
