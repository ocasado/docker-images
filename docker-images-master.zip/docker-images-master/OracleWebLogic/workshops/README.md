WebLogic on Docker Workshops
=====
Find here workshops for playing with WebLogic on Docker.

 1. [Introductory](./intro/)
 2. [Multihost](./multihost/)
